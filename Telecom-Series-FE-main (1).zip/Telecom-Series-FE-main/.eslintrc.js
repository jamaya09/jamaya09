/** @type {import("eslint").ESLint.Options} */
module.exports = {
  extends: ["@architecture-it/andreani/react"],
};
