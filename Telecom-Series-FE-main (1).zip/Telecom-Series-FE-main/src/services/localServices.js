export const propietarios = [
  {
    propietario: "TLM",
    tiposDeSeries: {
      imei: {
        digitos: 15,
        prefijo: "3",
      },
      sim: {
        digitos: 20,
        prefijo: "8",
      },
      accesorios: {
        digitos: 18,
        prefijo: "9",
      },
    },
  },
];
